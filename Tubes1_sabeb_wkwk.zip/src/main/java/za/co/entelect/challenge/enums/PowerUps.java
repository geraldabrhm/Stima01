package za.co.entelect.challenge.enums;

import com.google.gson.annotations.SerializedName;

public enum PowerUps {
    @SerializedName("BOOST")
    BOOST,
    @SerializedName("OIL")
    OIL,
    @SerializedName("TWEET")
    TWEET,
    @SerializedName("LIZARD")
    LIZARD,
    @SerializedName("EMP")
    EMP;
}
